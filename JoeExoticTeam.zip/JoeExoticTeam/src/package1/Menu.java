/**
 * The Menu class which is responsible for displaying the menu to the user, and getting a choice to play the game.
 * 
 * @author Yelena Trunina, Viola Zhuravel
 *
 * @version 1.0
 * @since 04/19/2020
 */

package package1;

import java.util.Scanner;
import package1.Attack;

public class Menu {

	public static Scanner sc;

	/**
	 * Menu Constructor
	 */

	Menu() {
		// Initialize Menu fields
		sc = new Scanner(System.in);
	} // end Menu Constructor

	/**
	 * Method for running the application
	 */

	public static void runAPP() {
		String menuChoice = "";

		// Loop until the user presses B
		while (!menuChoice.equals("B")) {
			System.out.printf("\nThis is Tiger Hunt, a game based off of the Tiger King!");
			System.out.println("\nMain Menu:");
			System.out.println("To Play New Game - Press A");
			System.out.println("To Exit - Press B");

			// Get Menu Choice from User
			menuChoice = sc.nextLine();
			menuChoice = menuChoice.toUpperCase();

			switch (menuChoice) {
			case "A":
				System.out.println("\nWelcome! My name is Joe Exotic.");
				Attack fight = new Attack();
				fight.fightTigerPack();
				break;
			case "B":
				System.out.println("\nThank you for playing this game!");
				System.exit(0);
			default:
				System.out.println("You can only enter upper and lower case characters between A and B\n");

			}// end switch
		} // end while loop
	} // end runApp
} // end Menu
