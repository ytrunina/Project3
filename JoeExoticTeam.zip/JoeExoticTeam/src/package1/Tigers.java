/**
 * The Tigers class which is responsible for keeping the record for each tiger within the game.
 * 
 * @author Tia Sharpe, Jorrell Smith
 *
 * @version 1.0
 * @since 04/19/2020
 */

package package1;

import java.util.Random;

public class Tigers {

	private String name = "";
	private int elude;
	private int attack;
	private int hitPoints;

	/**
	 * Tigers Constructor
	 * 
	 * @param tigerCount
	 */

	Tigers(int tigerCount) {
		// Initialize Tigers fields
		Random rand = new Random();
		int max = 50, min = 25;

		this.name = "Tiger " + tigerCount;
		this.elude = 50;
		this.attack = rand.nextInt((max - min) + 1) + min;
		this.hitPoints = rand.nextInt((max - min) + 1) + min;

	} // end Tigers Constructor

	/**
	 * Setter method for the Tigers Elude Field
	 * 
	 * @param elude
	 */

	public void setElude(int elude) {
		this.elude = elude;
	} // end setElude

	/**
	 * Getter method for the Tigers elude value
	 * 
	 * @return elude
	 */
	public int getElude() {
		return this.elude;
	} // end getElude

	/**
	 * Setter method for the Tigers Attack %
	 * 
	 * @param attack
	 */

	public void setAttack(int attack) {
		this.attack = attack;
	} // end setAttack

	/**
	 * Getter method for the Tigers attack value
	 * 
	 * @return attack
	 */

	public int getAttack() {
		return this.attack;
	} // end getAttack

	/**
	 * Setter method for the Tigers Hit Point, Or Strength * @param elude
	 */

	public void setHitPoints(int hitPoints) {
		this.hitPoints = hitPoints;
	} // end setHitPoints

	/**
	 * Getter method for the Tigers hit point value
	 * 
	 * @return hitPoints
	 */

	public int getHitPoints() {
		return this.hitPoints;
	} // end getHitPoints

	/**
	 * Getter method for the Tigers name value
	 * 
	 * @return name
	 */

	public String getName() {
		return this.name;
	} // end getName

	/**
	 * The attack method calculates at random, whether the tiger was successful with
	 * an attack based on the percentage of attack
	 */

	public boolean attack() {

		// Set a random number from 1 - 100 which acts as a %
		Random rand = new Random();
		int range = rand.nextInt(100) + 1;
		if (range <= this.attack)
			return true;

		return false;
	} // end attack

	/**
	 * The displayStats method displays the Tigers stats
	 */

	public void displayStats() {
		System.out.println(this.name);
		System.out.println("Hitpoints: " + this.hitPoints);
		System.out.println("Attack %: " + this.attack);
		System.out.println("Elude %: " + this.elude);
	} // end displayStats

}// end of tigers
