package package1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Attack {
	User user;
	List<Tigers> tigers = new ArrayList<>(6);
	private static Scanner keyboard;
	
	Attack() {
		this.user = new User();
		for (int i=0; i<6; i++) {
            this.tigers.add(new Tigers(i + 1));
        }//end of for
		
		Attack.keyboard = new Scanner(System.in);
	}
	
	Attack(String name) {
		this.user = new User(name);
		for (int i=0; i<6; i++) {
            this.tigers.add(new Tigers(i + 1));
        }//end of for
		
		Attack.keyboard = new Scanner(System.in);
	}
	
	
    public boolean freeTigers()
    {
    	if(this.tigers.size() > 0)
			return true;
		return false;
		
        /*boolean captured = false;
        for (Tigers t : tigers)
        {
            if (t.tigerIsNotCaptured())
            {
                captured = true;
                break;
            }
        }
        return true;*/
		
    }// end of living

    
    public void fightTigerPack()
    {
        String name = "";
        //User user = new User();
        System.out.print("Please enter your name: ");
        name = keyboard.nextLine();
        
        
        user.setUserName(name);
        //user.getUserName();

        System.out.println("\n\n");
		System.out.println("Try to capture a tiger but be careful, if you miss, the tiger will attack.\nTry feeding the tiger first!!!");
		//System.out.println("\n\n");
		
        //System.out.println(this.tigers.size());
        while(freeTigers() && this.user.isAlive()) {
        	//System.out.println("Im here");
        	Tigers nextTiger = this.tigers.get(0);
        	
        	if(this.user.isAlive()) {
        		
        		int userChoice;
        		
        		//displayStats();
        		//System.out.println(nextTiger.getName() + " is on the prowl!!!");
        		System.out.println("\n\n");
        		user.displayStats();
        		System.out.println("\nvs\n");
        		nextTiger.displayStats();
        		System.out.println("\n");
        		//System.out.println("******************************");
        		//System.out.printf("%17s\n", "SUB-MENU");
        		//System.out.println("******************************");
        		//System.out.println("\n\n");
        		
        		
        		System.out.println("1. - Sardine Oil (feed treat)  -25 Elude Points (" + user.getNumOfSardineTreats() + ")");
    			System.out.println("2. - Human Flesh (feed treat)  -25 Elude Points (" + user.getNumOfHumanTreats() + ")");
    			System.out.println("3. - Walmart Chicken (feed treat)  -15 Elude Points (" + user.getNumOfWalmartTreats() + ")");
    			System.out.println("4. - Perfect Combo - Sardine Oil + Human Flesh (feed treat)  -50 Elude Points");
    			System.out.println("5. - Capture the Tiger");
    			
    			//User Menu Choice
    			System.out.print("\nPlease select an option: ");
    			userChoice = keyboard.nextInt();
    			
    			System.out.println("\n\n");
    			int treatValue = 0;
    			
    			switch(userChoice) {
    				case 1:
    					if(nextTiger.getElude() > 0) {
	    					treatValue = user.feedTreat(Treats.SardineOil);
	    					
	    					if(nextTiger.getElude() - treatValue < 0)
	    						nextTiger.setElude(0);
	    					else
	    						nextTiger.setElude(nextTiger.getElude() - treatValue);
    					}
    					
    					else {
    						System.out.println("Tiger is full and unable to move");
    					}
    					
    					break;
    				case 2:
    					treatValue = user.feedTreat(Treats.HumanFlesh);
    					nextTiger.setElude(nextTiger.getElude() - treatValue);
    					break;
    				case 3:
    					treatValue = user.feedTreat(Treats.WalmartChicken);
    					nextTiger.setElude(nextTiger.getElude() - treatValue);
    					break;
    				case 4:
    					System.out.println("You picked the perfect combo, the tiger's gonna love this.");
    					treatValue = user.feedTreat(Treats.SardineOil) + user.feedTreat(Treats.HumanFlesh);
    					nextTiger.setElude(nextTiger.getElude() - treatValue);
    					break;
    				case 5:
    					boolean tigerIsCaptured = user.capturedTiger(user.getCapture() - nextTiger.getElude());
    					
    					if(tigerIsCaptured) {
    						this.tigers.remove(0);
    						System.out.println(nextTiger.getName() + " captured");
    					}
    					
    					else {
    						System.out.println("Uh oh, the tiger was not captured and is attacking");
    						boolean attackSucceeded = nextTiger.attack();
    						
    						if(attackSucceeded) {
    							System.out.println("Tiger has mauled you for " + nextTiger.getHitPoints() + " damage");
    							user.setHealth(user.getHealth() - nextTiger.getHitPoints());
    						}
    						
    						else {
    							System.out.println("You escaped without a scratch");
    						}
    					}
    					
    						
    			};
    			
    			//System.out.println(user.getHealth());
    			this.user.updateAliveStatus();
    			
    			/*
        		if(this.user.completedAttack()) {
                	nextTiger.userDies();
                    System.out.println(nextTiger.getName() + " killed");
                    this.tigers.remove(0);
                }
                
                else {
                	System.out.println(nextTiger.getName()+" tries to attack "+user.getName());
                    if(nextTiger.completedAttack()) {
                    	user.userDies();
                    	System.out.println(user.getName() + " killed");
                    }
                }//end if when check if tiger survived
                */
        	}
        }
        
        if(!this.user.isAlive()) {
        	System.out.println("Sorry, you're dead");
        }
        
        else {
        	System.out.println("Congratulations, you captured all the tigers");
        }
        //System.out.println("Im there");
        
        
        
        /*
        Random random = new Random();
        //List<Tigers> tigers = new ArrayList<>(6);
        //for (int i=0; i<=6; i++)
        //{
            //tigers.add(new Tigers("Tiger "));
        //}//end of for

        //int tigerHit = 0;
        //int userHit = 0;
        int count = 0;
        do{

            if (freeTigers(tigers))
            {
                for (Iterator<Tigers> iterator = tigers.iterator(); iterator.hasNext();)
                {

                    Tigers nextTiger = iterator.next();
                    nextTiger.setFinalCount();
                    if(nextTiger.tigerIsNotCaptured && user.isAlive())
                    {
                        nextTiger.setHitPoint(tigerHit);
                        user.setHitPoint(userHit);

                        if (nextTiger.getHitPoint()<user.getHitPoint())
                        {
                        	System.out.println("Im there");
                            nextTiger.isTigerIsCaptured();
                            System.out.print(nextTiger.getTigersNames() + " is captured.\n");

                            count++;
                        }

                        else if (nextTiger.getHitPoint()>user.getHitPoint())
                        {
                        	System.out.println("Im here");
                            user.isDead();
                            System.out.print("My friend, "+user.getUserName()+" - you are dead.\n");
                            System.out.print("Total tigers captured: " + count);
                        Menu menu2 = new Menu();
                        menu2.runAPP();
                        }
                        else if (nextTiger.getHitPoint()==user.getHitPoint())
                        {
                            while (nextTiger.getHitPoint()==user.getHitPoint())
                            {
                                nextTiger.getHitPoint();
                                user.getHitPoint();
                            }//end of while
                        }

                    }//end of next
                }//end of for
            }//end of if free tigers
        }while (!user.isAlive());//end of while user alive

        System.out.print("Total tigers captured: " + count);

        */
    }//end of fight
}//end of attack
