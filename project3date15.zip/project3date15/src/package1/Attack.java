/**
 * The Attack class which acts as a field of play for the User and the Tigers in the game.
 * 
 * @author Yelena Trunina, Viola Zhuravel
 *
 * @version 1.0
 * @since 04/19/2020
 */

package package1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Attack {
	User user;
	List<Tigers> tigers = new ArrayList<>(6);
	private static Scanner keyboard;
	
	
	/**
	 * Attack Constructor
	 */
	
	Attack() {
		//Initialize Attack fields
		this.user = new User();
		
		//Adds tigers to list
		for (int i=0; i<6; i++) {
            this.tigers.add(new Tigers(i + 1));
        }
		
		Attack.keyboard = new Scanner(System.in);
	} //end Attack Constructor
	
	
	/**
	 * Attack Constructor
	 * @param name
	 */
	
	Attack(String name) {
		//Initialize Attack fields
		this.user = new User(name);
		
		//Adds tigers to list
		for (int i=0; i<6; i++) {
            this.tigers.add(new Tigers(i + 1));
        }//end of for
		
		Attack.keyboard = new Scanner(System.in);
	} //end Attack Constructor
	
	
	/**
	 * The freeTigers method calculates if any tigers are left to capture
	 */
	
    public boolean freeTigers()
    {
    	//Size of the Array list
    	if(this.tigers.size() > 0)
			return true;
		return false;
		
    }// end of living

    
    /**
	 * The fightTigerPack method puts the user against the tiger horde.
	 * This is where the game takes place, as the user attempts to capture all tigers
	 * Or die trying	 
	 **/
    
    public void fightTigerPack()
    {
        String name = "";
        
        //Asks user for name
        System.out.print("Please enter your name: ");
        name = keyboard.nextLine();
        
        //Sets user name
        user.setUserName(name);
        

        System.out.println("\n\n");
		System.out.println("Try to capture a tiger but be careful, if you miss, the tiger will attack.\nTry feeding the tiger first!!!");
		
		
       
        while(freeTigers() && this.user.isAlive()) {
        	
        	//Get the first Tiger in the array list
        	Tigers nextTiger = this.tigers.get(0);
        	
        	if(this.user.isAlive()) {
        		
        		int userChoice;
        		
        		
        		System.out.println("\n\n");
        		
        		//Displays User stats
        		user.displayStats();
        		System.out.println("\nvs\n");
        		
        		//Display Tiger stats
        		nextTiger.displayStats();
        		System.out.println("\n");
        		
        		
        		//Displays the choices a user can make
        		System.out.println("1. - Sardine Oil (feed treat)  -25 Elude Points (" + user.getNumOfSardineTreats() + ")");
    			System.out.println("2. - Human Flesh (feed treat)  -25 Elude Points (" + user.getNumOfHumanTreats() + ")");
    			System.out.println("3. - Walmart Chicken (feed treat)  -15 Elude Points (" + user.getNumOfWalmartTreats() + ")");
    			System.out.println("4. - Perfect Combo - Sardine Oil + Human Flesh (feed treat)  -50 Elude Points");
    			System.out.println("5. - Capture the Tiger");
    			
    			//User Menu Choice
    			System.out.print("\nPlease select an option: ");
    			
    			//Get the users choice
    			userChoice = keyboard.nextInt();
    			
    			System.out.println("\n\n");
    			int treatValue = 0;
    			
    			switch(userChoice) {
    				case 1:
    					//Runs only if the elusiveness of the tiger is greater than 0
    					if(nextTiger.getElude() > 0) {
	    					treatValue = user.feedTreat(Treats.SardineOil);
	    					
	    					//If the value of the treat is greater than the elusive value of the tiger, make it 0, otherwise subtract the two values
	    					if(nextTiger.getElude() - treatValue < 0)
	    						nextTiger.setElude(0);
	    					else
	    						nextTiger.setElude(nextTiger.getElude() - treatValue);
    					}
    					
    					else {
    						System.out.println("Tiger is full and unable to move");
    					}
    					
    					break;
    				case 2:
    					//Runs only if the elusiveness of the tiger is greater than 0
    					if(nextTiger.getElude() > 0) {
	    					treatValue = user.feedTreat(Treats.HumanFlesh);
	    					
	    					//If the value of the treat is greater than the elusive value of the tiger, make it 0, otherwise subtract the two values
	    					if(nextTiger.getElude() - treatValue < 0)
	    						nextTiger.setElude(0);
	    					else
	    						nextTiger.setElude(nextTiger.getElude() - treatValue);
    					}
    					break;
    				case 3:
    					//Runs only if the elusiveness of the tiger is greater than 0
    					if(nextTiger.getElude() > 0) {
	    					treatValue = user.feedTreat(Treats.WalmartChicken);
	    					
	    					//If the value of the treat is greater than the elusive value of the tiger, make it 0, otherwise subtract the two values
	    					if(nextTiger.getElude() - treatValue < 0)
	    						nextTiger.setElude(0);
	    					else
	    						nextTiger.setElude(nextTiger.getElude() - treatValue);
    					}
    					break;
    				case 4:
    					//Runs only if the elusiveness of the tiger is greater than 0
    					if(nextTiger.getElude() > 0) {
	    					System.out.println("You picked the perfect combo, the tiger's gonna love this.");
	    					treatValue = user.feedTreat(Treats.SardineOil) + user.feedTreat(Treats.HumanFlesh);
	    					
	    					//If the value of the treat is greater than the elusive value of the tiger, make it 0, otherwise subtract the two values
	    					if(nextTiger.getElude() - treatValue < 0)
	    						nextTiger.setElude(0);
	    					else
	    						nextTiger.setElude(nextTiger.getElude() - treatValue);
    					}
    					break;
    				case 5:
    					//User tries to capture the tiger
    					boolean tigerIsCaptured = user.capturedTiger(user.getCapture() - nextTiger.getElude());
    					
    					//If Successful, remove the first Tiger in the array list
    					if(tigerIsCaptured) {
    						this.tigers.remove(0);
    						System.out.println(nextTiger.getName() + " captured");
    					}
    					
    					else {
    						System.out.println("Uh oh, the tiger was not captured and is attacking");
    						
    						//Tigers tries to attack
    						boolean attackSucceeded = nextTiger.attack();
    						
    						//if Tiger attack succeeds, set a new health for the user based of hit points
    						if(attackSucceeded) {
    							System.out.println("Tiger has mauled you for " + nextTiger.getHitPoints() + " damage");
    							user.setHealth(user.getHealth() - nextTiger.getHitPoints());
    						}
    						
    						else {
    							System.out.println("You escaped without a scratch");
    						}
    					}
    					
    					break;
    				default:
    					System.out.println("Please enter a menu option from 1 - 5, numbers only.");
    					break;
    					
    						
    			};
    			
    			//Update the alive status of the user
    			this.user.updateAliveStatus();
    			
    			
        	}
        }
        
        //Display to the user whether they won the game or not
        if(!this.user.isAlive()) {
        	System.out.println("Sorry, you're dead");
        }
        
        else {
        	System.out.println("Congratulations, you captured all the tigers");
        }
        
        
        
        
        
    }//end of fight
}//end of attack
