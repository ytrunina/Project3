/**
 * Welcome to Tiger Hunt, a game based off of the Tiger King.
 * The goal of the game is to capture as many tigers as you can, before being killed
 * The user start with 100 health, and a variety of methods to make capturing tigers easier.
 * Feed it a treat, and go for the capture, but watch out, they attack back if you miss
 * 
 * @author Viola Zhuravel, Yelena Trunina, Tia Sharpe, Jorrell Smith
 *
 * @version 1.0
 * @since 04/19/2020
 */

package package1;

import java.io.IOException;



public class Main {
	/**
	 * The main initializer of the program, function main
	 * @param args Command-line arguments
	 */
    public static void main(String[] args) throws IOException {
    	Menu menu = new Menu();
    	Menu.runAPP();
    }
} // end Main
