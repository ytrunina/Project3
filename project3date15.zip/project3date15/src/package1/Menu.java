package package1;

import java.util.Scanner;
import package1.Attack;

public class Menu {

	public static Scanner sc;

	Menu() {
		sc = new Scanner(System.in);
	}

    public static char readChar() {
        sc = new Scanner(System.in);
        String res = sc.next();
        char result = res.charAt(0);
        result = Character.toUpperCase(result);
        if (result >= 'A' && result <= 'D') {
            return result;
        } else {
            do {
                do {
                    System.out.println("You can only enter upper and lower case characters between A and B");
                    result = sc.next().charAt(0);
                    result = Character.toUpperCase(result);
                } while(result < 'A');
            } while(result > 'B');

            return result;
        }
    }
    
    public static void runAPP()  {
    	String menuChoice = "";
    	
        while(!menuChoice.equals("B")) {
    		System.out.println("\n\n");
    		System.out.println("******************************");
    		System.out.printf("%17s\n", "MENU");
    		System.out.println("******************************");
            System.out.println("\n\nA - Play New Game");
            System.out.println("B - Exit the Game");
            
            
            menuChoice = sc.nextLine();
			menuChoice = menuChoice.toUpperCase();
			
            switch(menuChoice) {
                case "A":
                    System.out.println("\n\nWelcome! My name is Joe Exotic.");
                    Attack fight = new Attack();
                    fight.fightTigerPack();
                    break;
                case "B":
                    System.out.println("\n\nThank you for playing this game!");
                    System.exit(0);
                default:
                	System.out.println("You can only enter upper and lower case characters between A and B");

            }
        }
    }
}
