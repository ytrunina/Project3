package package1;

public enum Treats {
	 SardineOil, HumanFlesh, WalmartChicken 
}
