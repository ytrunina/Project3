/**
 * The Enum for the available Treats to feed tot he tigers.
 * 
 * @author Yelena Trunina, Jorrell Smith
 *
 * @version 1.0
 * @since 04/19/2020
 */

package package1;

public enum Treats {
	 SardineOil, HumanFlesh, WalmartChicken 
}
