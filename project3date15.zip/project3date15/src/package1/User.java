/**
 * The User class which is responsible for keeping the record for user playing the game.
 * 
 * @author Tia Sharpe, Jorrell Smith
 *
 * @version 1.0
 * @since 04/19/2020
 */

package package1;


import java.util.Random;

public class User {

	private String name = "";	// Users name
	private int capture;	// Users capture value
	private boolean isAlive;	// User is alive
	private int health;			// Users health
	private int numOfSardineTreats;		//Users number of sardine treats
	private int numOfHumanTreats;		//Users number of human treats
	private int numOfWalmartTreats;		//Users number of walmart treats
	
	/**
	 * User Constructor
	 */
	
	User() {
		//Initialize the User fields
		this.name = "User";
		this.capture = 75;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	} //end User Constructor
	
	
	/**
	 * User Constructor
	 * @param name
	 */
	
	User(String name) {
		//Initialize the User fields
		this.name = name;
		this.capture = 75;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	} //end User Constructor
	
	
	/**
	 * User Constructor
	 * @param name
	 * @param capture
	 */
	
	User(String name, int capture) {
		//Initialize the User fields
		this.capture = capture;
		this.capture = capture;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	} //end User Constructor
	
	
	/**
	 * Getter method for the Users capture value
	 * @return capture
	 */
	
	public int getCapture() {
		return this.capture;
	} //end getCapture
	
	
	/**
	 * The isAlive method is tyo determine if the user is alive or not
	 * @return true
	 * @return false
	 */
	
	public boolean isAlive() {
		if(this.isAlive)
			return true;
	
		return false;
    }// end of is alive
	
	
	/**
	 * The updateAliveStatus method updates the alive status of the user
	 */
	
	public void updateAliveStatus() {
		if(this.health <= 0) 
			this.isAlive = false;
	} //end updateAliveStatus
	
	
	/**
	 * Setter method for the Users Health
	 * @param health
	 */
	
	public void setHealth(int health) {
		this.health = health;
	} //end setHealth
	
	
	/**
	 * Getter method for the Users health
	 * @return health
	 */
	
	public int getHealth() {
		return this.health;
	} //end getHEalth
	
	
	/**
	 * Setter method for the Users Name
	 * @param name
	 */
	
	public void setUserName(String name) {
		this.name = name;
	} //end setUserName
	
	
	/**
	 * Getter method for the Users name
	 * @return name
	 */
	
	public String getUserName() {
		return this.name;
	} //end getUserName
	
	
	/**
	 * The capturedTiger method calculates at random, whether the tiger was captured or not based on the percentage of capture
	 * @param capture
	 */
	
	public boolean capturedTiger(int capture) {
		
		//Set a random number from 1 - 100 which acts as a %
		Random rand = new Random();
		int range = rand.nextInt(100) + 1;
		
		if(range <= capture)
			return true;
		
		return false;
	} //end capturedTiger
	
	
	/**
	 * Setter method for the Users number of available sardine treats
	 * @param numOfSardineTreats
	 */
	
	public void setNumOfSardineTreats( int numOfSardineTreats ) {
		this.numOfSardineTreats = numOfSardineTreats;
	} //end setNumOfSardineTreats
	
	
	/**
	 * Getter method for the Users number of available sardine treats
	 * @return numOfSardineTreats
	 */
	
	public int getNumOfSardineTreats() {
		return this.numOfSardineTreats;
	} //end getNumOfSardineTreats
	
	
	/**
	 * Setter method for the Users number of available human treats
	 * @param numOfHumanTreats
	 */
	
	public void setNumOfHumanTreats( int numOfHumanTreats ) {
		this.numOfHumanTreats = numOfHumanTreats;
	} //end setNumOfHumanTreats
	
	
	/**
	 * Getter method for the Users number of available human treats
	 * @return numOfHumanTreats
	 */
	
	public int getNumOfHumanTreats() {
		return this.numOfHumanTreats;
	} // end getNumOfHumanTreats
	
	
	/**
	 * Setter method for the Users number of available walmart treats
	 * @param numOfWalmartTreats
	 */
	
	public void setNumOfWalmartTreats( int numOfWalmartTreats ) {
		this.numOfWalmartTreats = numOfWalmartTreats;
	} // end setNumWalmartTreats
	
	
	/**
	 * Getter method for the Users number of available walmart treats
	 * @return numOfWalmartTreats
	 */
	
	public int getNumOfWalmartTreats() {
		return this.numOfWalmartTreats;
	} //end getNumOfWalmartTreats
	
	
	/**
	 * The feedTreat method feed a treat, dropping the elusiveness of the tiger
	 * @param treat
	 */
	
	public int feedTreat(Treats treat) {
		int treatValue = 0;
		
		//Return a treat value for the corresponding treat enum
		switch(treat) {
			case SardineOil:
				if(getNumOfSardineTreats() <= 0)
					System.out.println("You've used up all your Sardine Oil");
				else {
					treatValue = 25;
					setNumOfSardineTreats(getNumOfSardineTreats() - 1);
				}
				break;
			case HumanFlesh:
				if(getNumOfHumanTreats() <= 0)
					System.out.println("You've used up all your Human Treats");
				else {
					treatValue = 25;
					setNumOfHumanTreats(getNumOfHumanTreats() - 1);
				}
				break;
			case WalmartChicken:
				if(getNumOfWalmartTreats() <= 0)
					System.out.println("You've used up all your Walmart Chicken");
				else {
					treatValue = 15;
					setNumOfWalmartTreats(getNumOfWalmartTreats() - 1);
				}
				break;
		}

		return treatValue;
	} //end feedTreat
	
	
	/**
	 * The displayStats method displays the Users stats
	 */
	
	public void displayStats() {
		System.out.println(this.name);
    	System.out.println("Health: " + this.health);
    	System.out.println("Capture %: " + this.capture);
	} //end displayStats
	
    
} // end User
