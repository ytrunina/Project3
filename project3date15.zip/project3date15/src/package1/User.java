package package1;


import java.util.Random;

public class User {

	private String name = "";
	private int capture;
	private boolean isAlive;
	private int health;
	//public Treats treats;
	private int numOfSardineTreats;
	private int numOfHumanTreats;
	private int numOfWalmartTreats;
	
	User() {
		this.name = "User";
		this.capture = 75;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	}
	
	User(String name) {
		this.name = name;
		this.capture = 75;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	}
	
	User(String name, int capture) {
		this.capture = capture;
		this.capture = capture;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	}
	
	public int getCapture() {
		return this.capture;
	}
	
	public boolean isAlive() {
		if(this.isAlive)
			return true;
	
		return false;
    }// end of is alive
	
	public void updateAliveStatus() {
		if(this.health <= 0) 
			this.isAlive = false;
	}
	
	public void setHealth(int health) {
		this.health = health;
	}
	
	public int getHealth() {
		return this.health;
	}
	
	public void setUserName(String name) {
		this.name = name;
	}
	
	public String getUserName() {
		return this.name;
	}
	
	public boolean capturedTiger(int capture) {
		
		Random rand = new Random();
		int range = rand.nextInt(100) + 1;
		
		if(range <= capture)
			return true;
		
		return false;
	}
	
	public void setNumOfSardineTreats( int numOfSardineTreats ) {
		this.numOfSardineTreats = numOfSardineTreats;
	}
	
	public int getNumOfSardineTreats() {
		return this.numOfSardineTreats;
	}
	
	public void setNumOfHumanTreats( int numOfHumanTreats ) {
		this.numOfHumanTreats = numOfHumanTreats;
	}
	
	public int getNumOfHumanTreats() {
		return this.numOfHumanTreats;
	}
	
	public void setNumOfWalmartTreats( int numOfWalmartTreats ) {
		this.numOfWalmartTreats = numOfWalmartTreats;
	}
	
	public int getNumOfWalmartTreats() {
		return this.numOfWalmartTreats;
	}
	
	
	public int feedTreat(Treats treat) {
		//Treats feed = Treats.SardineOil;
		int treatValue = 0;
		switch(treat) {
			case SardineOil:
				if(getNumOfSardineTreats() <= 0)
					System.out.println("You've used up all your Sardine Oil");
				else {
					treatValue = 25;
					setNumOfSardineTreats(getNumOfSardineTreats() - 1);
				}
				break;
			case HumanFlesh:
				if(getNumOfHumanTreats() <= 0)
					System.out.println("You've used up all your Human Treats");
				else {
					treatValue = 25;
					setNumOfHumanTreats(getNumOfHumanTreats() - 1);
				}
				break;
			case WalmartChicken:
				if(getNumOfWalmartTreats() <= 0)
					System.out.println("You've used up all your Walmart Chicken");
				else {
					treatValue = 15;
					setNumOfWalmartTreats(getNumOfWalmartTreats() - 1);
				}
				break;
		}

		return treatValue;
	}
	
	public void displayStats() {
		System.out.println(this.name);
    	System.out.println("Health: " + this.health);
    	System.out.println("Capture %: " + this.capture);
	}
	
    //private int hitPoint;
    //private boolean gameOver = false;
    //private boolean isAlive = true;
    //private Random rand = new Random();

    //private String userName = "";

     //User(String m_playerName) {

        //this.hitPoint = 0;
        //this.userName = userName;
    //}//end of user

    //public User() {

    //}

    /**
     * Setter method for the Players Name
     * @param userName
     */

    /*
    public void setUserName(String userName) {

        this.userName = userName;
        Scanner keyboard = new Scanner(System.in);
        this.userName = keyboard.nextLine();

    }
    
    public String getUserName() {
        return this.userName;
    }*/
    
    /*
    public int setHitPoint(int hitPoint) {
        int intHitPoint=0;
        for (int i=0; i<10;i++)
        {
            intHitPoint=getRandomInRange(1,10);
        }
        this.hitPoint = intHitPoint;
        return hitPoint;
    }
    public int getHitPoint() {
        return hitPoint;
    }//end of hitpoint
	*/
    
    /*
    public boolean isAlive()
    {
        return isAlive;
    }// end of is alive

    public boolean isDead()
    {
        isAlive=false;
        return false;
    }//end of is dead
	*/

    /*
    private static int getRandomInRange(int min, int max)
    {
        if (min>=max)
        {
            throw new IllegalArgumentException("max must be greater than min");
        }
        Random rand = new Random();
        return rand.nextInt(((max-min)+1)+min);
    }
    */
}
