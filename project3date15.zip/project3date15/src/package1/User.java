/**
 * The User class which is responsible for keeping the record for user playing the game.
 * 
 * @author Tia Sharpe, Jorrell Smith
 *
 * @version 1.0
 * @since 04/19/2020
 */

package package1;


import java.util.Random;

public class User {

	private String name = "";
	private int capture;
	private boolean isAlive;
	private int health;
	private int numOfSardineTreats;
	private int numOfHumanTreats;
	private int numOfWalmartTreats;
	
	/**
	 * User Constructor
	 */
	
	User() {
		this.name = "User";
		this.capture = 75;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	}
	
	
	/**
	 * User Constructor
	 * @param name
	 */
	
	User(String name) {
		this.name = name;
		this.capture = 75;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	}
	
	
	/**
	 * User Constructor
	 * @param name
	 * @param capture
	 */
	
	User(String name, int capture) {
		this.capture = capture;
		this.capture = capture;
		this.isAlive = true;
		this.health = 100;
		this.numOfSardineTreats = 2;
		this.numOfHumanTreats = 1;
		this.numOfWalmartTreats = 2;
	}
	
	
	/**
	 * Getter method for the Users capture value
	 * @return capture
	 */
	
	public int getCapture() {
		return this.capture;
	}
	
	
	/**
	 * The isAlive method is tyo determine if the user is alive or not
	 * @return true
	 * @return false
	 */
	
	public boolean isAlive() {
		if(this.isAlive)
			return true;
	
		return false;
    }// end of is alive
	
	
	/**
	 * The updateAliveStatus method updates the alive status of the user
	 */
	
	public void updateAliveStatus() {
		if(this.health <= 0) 
			this.isAlive = false;
	}
	
	
	/**
	 * Setter method for the Users Health
	 * @param health
	 */
	
	public void setHealth(int health) {
		this.health = health;
	}
	
	
	/**
	 * Getter method for the Users health
	 * @return health
	 */
	
	public int getHealth() {
		return this.health;
	}
	
	
	/**
	 * Setter method for the Users Name
	 * @param name
	 */
	
	public void setUserName(String name) {
		this.name = name;
	}
	
	
	/**
	 * Getter method for the Users name
	 * @return name
	 */
	
	public String getUserName() {
		return this.name;
	}
	
	
	/**
	 * The capturedTiger method calculates at random, whether the tiger was captured or not based on the percentage of capture
	 * @param capture
	 */
	
	public boolean capturedTiger(int capture) {
		
		Random rand = new Random();
		int range = rand.nextInt(100) + 1;
		
		if(range <= capture)
			return true;
		
		return false;
	}
	
	
	/**
	 * Setter method for the Users number of available sardine treats
	 * @param numOfSardineTreats
	 */
	
	public void setNumOfSardineTreats( int numOfSardineTreats ) {
		this.numOfSardineTreats = numOfSardineTreats;
	}
	
	
	/**
	 * Getter method for the Users number of available sardine treats
	 * @return numOfSardineTreats
	 */
	
	public int getNumOfSardineTreats() {
		return this.numOfSardineTreats;
	}
	
	
	/**
	 * Setter method for the Users number of available human treats
	 * @param numOfHumanTreats
	 */
	
	public void setNumOfHumanTreats( int numOfHumanTreats ) {
		this.numOfHumanTreats = numOfHumanTreats;
	}
	
	
	/**
	 * Getter method for the Users number of available human treats
	 * @return numOfHumanTreats
	 */
	
	public int getNumOfHumanTreats() {
		return this.numOfHumanTreats;
	}
	
	
	/**
	 * Setter method for the Users number of available walmart treats
	 * @param numOfWalmartTreats
	 */
	
	public void setNumOfWalmartTreats( int numOfWalmartTreats ) {
		this.numOfWalmartTreats = numOfWalmartTreats;
	}
	
	
	/**
	 * Getter method for the Users number of available walmart treats
	 * @return numOfWalmartTreats
	 */
	
	public int getNumOfWalmartTreats() {
		return this.numOfWalmartTreats;
	}
	
	
	/**
	 * The feedTreat method feed a treat, dropping the elusiveness of the tiger
	 * @param treat
	 */
	
	public int feedTreat(Treats treat) {
		//Treats feed = Treats.SardineOil;
		int treatValue = 0;
		switch(treat) {
			case SardineOil:
				if(getNumOfSardineTreats() <= 0)
					System.out.println("You've used up all your Sardine Oil");
				else {
					treatValue = 25;
					setNumOfSardineTreats(getNumOfSardineTreats() - 1);
				}
				break;
			case HumanFlesh:
				if(getNumOfHumanTreats() <= 0)
					System.out.println("You've used up all your Human Treats");
				else {
					treatValue = 25;
					setNumOfHumanTreats(getNumOfHumanTreats() - 1);
				}
				break;
			case WalmartChicken:
				if(getNumOfWalmartTreats() <= 0)
					System.out.println("You've used up all your Walmart Chicken");
				else {
					treatValue = 15;
					setNumOfWalmartTreats(getNumOfWalmartTreats() - 1);
				}
				break;
		}

		return treatValue;
	}
	
	
	/**
	 * The displayStats method displays the Users stats
	 */
	
	public void displayStats() {
		System.out.println(this.name);
    	System.out.println("Health: " + this.health);
    	System.out.println("Capture %: " + this.capture);
	}
	
    
}
